<?php

include '../helpers/bootstrap.php';

$db = new DB;

$db->hallo();
