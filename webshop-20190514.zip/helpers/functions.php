<?php

function dd($variable)
{
    var_dump($variable);
    die();
}
