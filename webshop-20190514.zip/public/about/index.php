<?php
    include '../../helpers/bootstrap.php'; // laadt alle benodigdheden in

    $title = 'About';
    include "../../partials/head.php";

    include "../../partials/menu.php";
?>

<div class="container">
    About
</div>

<?php include "../../partials/footer.php"; ?>
