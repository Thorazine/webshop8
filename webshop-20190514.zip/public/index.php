<?php
    include '../helpers/bootstrap.php'; // laadt alle benodigdheden in

    $title = 'Home';
    include "../partials/head.php";
?>

<?php include "../partials/menu.php"; ?>

<div class="container">
    Home
</div>

<?php include "../partials/footer.php"; ?>
